

#ifndef compile_h
#define compile_h

#include "structs.h"
#include "symbolTable.h"

extern const char VAR_PREFIX[];
extern const int VAR_PREFIX_LENGTH;

void compile(program * p);



void printHead();


void printFoot();

void declareVars(declarationSeq * decls, int tabs);
void printStatements(statementSeq * stmts, int tabs);
void printAssignment(assignment * a, int tabs);
void printIf(ifStatement * i, int tabs);
void printWhile(whileStatement * w, int tabs);
void printWriteInt(writeInt * w, int tabs);
void printExpression(expression * e);
void printSimpleExpression(simpleExpression * e);
void printTerm(term * t);
void printFactor(factor * f);


char * getVarName(symbol * s);

#endif
