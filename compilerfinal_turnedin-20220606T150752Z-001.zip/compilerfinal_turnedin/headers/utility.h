

#ifndef utility_h
#define utility_h


void printLeadLines(int tabs);
void printLines(int tabs);


void printTabs(int tabs);

#endif
