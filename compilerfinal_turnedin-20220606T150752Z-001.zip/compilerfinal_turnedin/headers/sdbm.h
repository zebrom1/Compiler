

#ifndef sdbm_h
#define sdbm_h


unsigned long hash(const unsigned char *);

#endif
