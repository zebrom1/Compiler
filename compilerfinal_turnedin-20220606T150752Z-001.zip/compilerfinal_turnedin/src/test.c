#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

int readInt() {
        printf("%s", "Please type an integer: ");
        char * s = NULL;
        size_t length;
        getline(&s, &length, stdin);
        int n = atoi(s);
        free(s);
        return n;
}

int main() {
        int tl13_N = 0;
        int tl13_SQRT = 0;

        tl13_N = readInt();
        tl13_SQRT = 0;
        while (tl13_SQRT * tl13_SQRT <= tl13_N) {
                tl13_SQRT = tl13_SQRT + 1;
        }
        tl13_SQRT = tl13_SQRT - 1;
        printf("%d\n", tl13_SQRT);

        return 0;
}
