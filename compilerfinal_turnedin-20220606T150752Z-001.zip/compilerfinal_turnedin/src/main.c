

#define __STDC_WANT_LIB_EXT2__ 1
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdarg.h>

#include "utility.h"
#include "structs.h"
#include "symbolTable.h"
#include "main.h"

void printProgramTree(program * p) {
    node n;
    n.p = p;


    printTree(n, e_p, 0);
}

void printTree(node n, nodeType_e t, int tabs) {
    node p;
    switch(t) {
        case e_p:
            printLines(tabs);
            printf("Node type: %s\n", "program");
            p.decls = n.p->decls;
            printTree(p, e_decls, tabs + 1);
            p.stmts = n.p->stmts;
            printTree(p, e_stmts, tabs + 1);
            break;
        case e_decls:
            printLines(tabs);
            printf("type: %s\n", "declarationSeq");
            printLines(tabs);
            printf("Count: %d\n", n.decls->count);
            printLines(tabs);
            printf("size: %d\n", n.decls->size);
             for(int i = n.decls->count - 1; i >= 0; i--) {
                p.decl = n.decls->decls[i];
                printTree(p, e_decl, tabs + 1);
                if(i != 0) {
                    printLeadLines(tabs + 1);
                    printf("=\n");
                }
            }
             break;
        case e_decl: {
            symbol * s = getSymbol(n.decl->varHandle);
            printLines(tabs);
            printf("type: %s\n", "declaration");
            printLines(tabs);
            printf("identifier: %s\n", s->key);
            printLines(tabs);
            printf("Variable type: %s\n", getVarType(s->type));
			}   break;
        case e_stmts:
            printLines(tabs);
            printf(" type: %s\n", "statementSeq");
            printLines(tabs);
            printf("count: %d\n", n.stmts->count);
            printLines(tabs);
            printf("size: %d\n", n.stmts->size);
           for(int i = n.stmts->count - 1; i >= 0; i--) {
                p.stmt = n.stmts->stmts[i];
                printTree(p, e_stmt, tabs + 1);
                if(i != 0) {
                    printLeadLines(tabs + 1);
                    printf("=\n");
                }
            }
            //free(n.stmts);
            break;
        case e_stmt:
            printLines(tabs);
            printf("type: %s\n", "statement");
            printLines(tabs);
            printf("type: %s\n", getStatementType(n.stmt->type));
            switch(n.stmt->type) {
                case ASSIGN_STMT:
                    p.asgn = n.stmt->u.asgnStmt;
                    printTree(p, e_asgn, tabs + 1);
                    break;
                case IF_STMT:
                    p.ifstmt = n.stmt->u.ifStmt;
                    printTree(p, e_ifstmt, tabs + 1);
                    break;
                case WHILE_STMT:
                    p.wstmt = n.stmt->u.whileStmt;
                    printTree(p, e_wstmt, tabs + 1);
                    break;
                case WRITEINT_STMT:
                    p.wint = n.stmt->u.writeIntStmt;
                    printTree(p, e_wint, tabs + 1);
                    break;
                default:
                    printLines(tabs);
                    printf("wat...");
                    break;
            }
            break;
        case e_asgn:
            printLines(tabs);
            printf("type: %s\n", "assignment");
            printLines(tabs);
            printf("Assignment type: %s\n", getAssignmentType(n.asgn->type));
            printLines(tabs);
            printf(" identifier: %s\n", getSymbol(n.asgn->varHandle)->key);
            if(n.asgn->type == ASSIGN_EXPR) {
                p.expr = n.asgn->expr;
                printTree(p, e_expr, tabs + 1);
            }
            //free(n.asgn);
            break;
        case e_ifstmt:
            printLines(tabs);
            printf("type: %s\n", "ifStatement");
            printLines(tabs);
            printLines(tabs);
            p.expr = n.ifstmt->condition;
            printTree(p, e_expr, tabs + 1);
            printLines(tabs);
            printf(" true:\n");
            p.stmts = n.ifstmt->ifTrue;
            printTree(p, e_stmts, tabs + 1);
            if(n.ifstmt->hasElse) {
                printLines(tabs);
                printf(" false:\n");
                p.stmts = n.ifstmt->ifFalse;
                printTree(p, e_stmts, tabs + 1);
            }

            break;
        case e_wstmt:   
            printLines(tabs);
            printf(" type: %s\n", "whileStatement");
            printLines(tabs);

            p.expr = n.wstmt->condition;
            printTree(p, e_expr, tabs + 1);
            printLines(tabs);
            printf("While true:\n");
            p.stmts = n.wstmt->whileTrue;
            printTree(p, e_stmts, tabs + 1);

            break;
        case e_wint:
            printLines(tabs);
            printf("type: %s\n", "writeInt");
            p.expr = n.wint->expr;
            printTree(p, e_expr, tabs + 1);

            break;
        case e_expr:
            printLines(tabs);
            printf("node type: %s\n", "expression");
            printLines(tabs);
            printf("var type: %s\n", getVarType(n.expr->type));
            if(n.expr->operands == 1) {
                p.sexpr = n.expr->left;
                printTree(p, e_sexpr, tabs + 1);
            }
            else {
                printLines(tabs);
                printf("operator: %s\n", getOp4Str(n.expr->op));
                printLines(tabs);
                printf("left op:\n");
                p.sexpr = n.expr->left;
                printTree(p, e_sexpr, tabs + 1);
                printLines(tabs);
                printf("right op:\n");
                p.sexpr = n.expr->right;
                printTree(p, e_sexpr, tabs + 1);
            }
            break;
        case e_sexpr:
            printLines(tabs);
            printf("node type: %s\n", "simpleExpression");
            printLines(tabs);
            printf("var Type: %s\n", getVarType(n.sexpr->type));
            if(n.sexpr->operands == 1) {
                p.trm = n.sexpr->left;
                printTree(p, e_trm, tabs + 1);
            }
            else {
                printLines(tabs);
                printf("operator: %s\n", getOp3Str(n.sexpr->op));
                printLines(tabs);
                printf("left op:\n");
                p.trm = n.sexpr->left;
                printTree(p, e_trm, tabs + 1);
                printLines(tabs);
                printf("right op:\n");
                p.trm = n.sexpr->right;
                printTree(p, e_trm, tabs + 1);
            }
            
            break;
        case e_trm:
            printLines(tabs);
            printf("node type: %s\n", "term");
            printLines(tabs);
            printf("Type: %s\n", getVarType(n.trm->type));
            if(n.trm->operands == 1) {
                p.fact = n.trm->left;
                printTree(p, e_fact, tabs + 1);
            }
            else {
                printLines(tabs);
                printf("Operator: %s\n", getOp2Str(n.trm->op));
                printLines(tabs);
                printf("left op:\n");
                p.fact = n.trm->left;
                printTree(p, e_fact, tabs + 1);
                printLines(tabs);
                printf("right op:\n");
                p.fact = n.trm->right;
                printTree(p, e_fact, tabs + 1);
            }
           
            break;
        case e_fact:
            printLines(tabs);
            printf("node type: %s\n", "factor");
            printLines(tabs);
            printf("fact type: %s\n", getFactorType(n.fact->factorType));
            printLines(tabs);
            printf(" Var type: %s\n", getVarType(n.fact->type));
            switch(n.fact->factorType) {
                case FACTOR_VAR:
                    printLines(tabs);
                    printf(" ident: %s\n", getSymbol(n.fact->u.varHandle)->key);
                    break;
                case FACTOR_NUM:
                    printLines(tabs);
                    printf("int : %d\n", n.fact->u.num);
                    break;
                case FACTOR_BOOL:
                    printLines(tabs);
                    printf("bool: %s\n", n.fact->u.boollit ? "true" : "false");
                    break;
                case FACTOR_EXPR:
                    p.expr = n.fact->u.expr;
                    printTree(p, e_expr, tabs + 1);
                    break;
                default:
                    printLines(tabs);
                    printf("wat...\n");
                    break;
            }
             break;
        default:
            printLines(tabs);
            printf("why....\n");
            break;
    }
}

void yyerror(const char * s, ...) {
    va_list args;

    va_start(args, s);

    fprintf(stderr, "\n\nerr: ");
    vfprintf(stderr, s, args);
    fprintf(stderr, "\n\n");

    va_end(args);

    exit(1);
}

int main() {
    initSymbolTable();



    if(!yyparse())
       

    freeSymbolTable();

    return 0;
}
