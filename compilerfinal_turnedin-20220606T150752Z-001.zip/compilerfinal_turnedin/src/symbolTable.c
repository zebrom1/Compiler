
#define __STDC_WANT_LIB_EXT2__ 1
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "sdbm.h"
#include "structTypes.h"
#include "symbolTable.h"

bool symbolTable_inited = false;


const unsigned int HASH_MAP_SIZE = 31;

st_node ** hashMap;

int symbolTableSize = 16;
int symbolTableLength = 0;


symbol ** symbolTable;



symbol * getSymbol(int i) {
    if(!symbolTable_inited)
        return NULL;

    if(i < 0 || i >= symbolTableLength)
        return NULL;

    return symbolTable[i];
}



int getHandle(const char * const name) {
    int hashVal = hash(name) % HASH_MAP_SIZE;

    st_node * n = hashMap[hashVal];

	
    while(n != NULL) {
		
        if(strcmp(symbolTable[n->index]->key, name) == 0)
			
            return n->index;
        n = n->next;
    }

	
    return -1;
}



int addSymbol(const char * const name, varType_e type) {
    int hashVal = hash(name) % HASH_MAP_SIZE;


    st_node ** p = hashMap + hashVal;

	
    while(*p != NULL) {
        
        if(strcmp(symbolTable[(*p)->index]->key, name) == 0)
            return -1;
		
        p = &((*p)->next);
    }



    
    if(symbolTableSize == symbolTableLength) {
        int newSize = symbolTableSize * 2;
        symbolTable = (symbol **) realloc(symbolTable, sizeof(symbol *) * symbolTableSize);
		
		
		for(int i = symbolTableSize; i < newSize; i++)
			symbolTable[i] = NULL;
		
		symbolTableSize = newSize;
    }

	
    int index = symbolTableLength++;

	(*p) = (st_node *) malloc(sizeof(st_node));
    (*p)->index = index;
    (*p)->next = NULL;

	
    symbolTable[index] = (symbol *) malloc(sizeof(symbol));
    symbolTable[index]->key = (char *) malloc(sizeof(char) * (strlen(name) + 1));
    strcpy(symbolTable[index]->key, name);

    symbolTable[index]->type = type;

	
    return index;
}


void initSymbolTable() {
    if(!symbolTable_inited) {
		hashMap = (st_node **) malloc(sizeof(st_node *) * HASH_MAP_SIZE);
		for(int i = 0; i < HASH_MAP_SIZE; i++)
            hashMap[i] = NULL;
        symbolTable = (symbol **) malloc(sizeof(symbol *) * symbolTableSize);
        for(int i = 0; i < symbolTableSize; i++)
            symbolTable[i] = NULL;
        symbolTable_inited = true;
    }
}


void freeSymbolTable() {
	
    if(symbolTable_inited) {
		        st_node * p;
        for(int i = 0; i < HASH_MAP_SIZE; i++) {
            p = hashMap[i];
            while(p != NULL) {
                st_node * temp = p->next;
                free(p);
                hashMap[i] = NULL;
                p = temp;
            }
        }
        
        free(hashMap);
        hashMap = NULL;

        
        for(int i = 0; i < symbolTableLength; i++) {
            free(symbolTable[i]);
            symbolTable[i] = NULL;
        }

        free(symbolTable);
        symbolTable = NULL;

        symbolTableSize = 16;
        symbolTable_inited = false;
    }
}
